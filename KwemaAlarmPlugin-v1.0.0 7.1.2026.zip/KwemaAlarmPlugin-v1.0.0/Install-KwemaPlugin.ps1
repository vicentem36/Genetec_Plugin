#Requires -Version 5.1
#Requires -RunAsAdministrator
<#
.SYNOPSIS
    Interactive installer for the KwemaAlarmPlugin on Genetec Security Center 5.13.

.DESCRIPTION
    Walks the operator through the full deployment process: stopping Genetec
    Server, backing up the previous installation, deploying plugin files,
    registering Windows Registry keys, and restarting the service.

    The script must be located in the same folder as the plugin files
    (KwemaAlarmPlugin.dll, Newtonsoft.Json.dll, Certificates\*.cert).
    Typically, this means: extract the release ZIP to any folder on the
    C: drive, then run the script from that folder.

.PARAMETER InstallRoot
    Destination folder for the plugin. Defaults to:
    C:\Program Files (x86)\Genetec Security Center 5.13\Plugins\KwemaAlarmPlugin

.PARAMETER ServiceName
    Name of the Genetec Windows service. Defaults to: GenetecServer.

.PARAMETER SourceDir
    Folder that contains the plugin files to deploy. Defaults to the script's
    own folder ($PSScriptRoot), which is the correct value when the script
    runs alongside the extracted release contents.

.PARAMETER Silent
    (Reserved for future automation) runs without interactive prompts.

.EXAMPLE
    cd "C:\KwemaInstaller\KwemaAlarmPlugin-v1.0.0"
    .\Install-KwemaPlugin.ps1

.NOTES
    Must be run from an elevated PowerShell session (Run as Administrator).
    To bypass the default execution policy for unsigned scripts, run:
        powershell -ExecutionPolicy Bypass -File .\Install-KwemaPlugin.ps1
#>

[CmdletBinding()]
param(
    [string]$InstallRoot = "C:\Program Files (x86)\Genetec Security Center 5.13\Plugins\KwemaAlarmPlugin",

    [string]$ServiceName = "GenetecServer",

    [string]$SourceDir,

    [switch]$Silent
)

$ErrorActionPreference = "Stop"

# ---------------------------------------------------------------------------
# Resolve SourceDir with multiple fallbacks. $PSScriptRoot inside a param
# default value is unreliable across PowerShell versions/launchers, so we
# resolve it here, in the script body, where it always works.
# ---------------------------------------------------------------------------
if ([string]::IsNullOrWhiteSpace($SourceDir)) {
    if (-not [string]::IsNullOrWhiteSpace($PSScriptRoot)) {
        $SourceDir = $PSScriptRoot
    }
    elseif ($MyInvocation.MyCommand.Path) {
        $SourceDir = Split-Path -Parent $MyInvocation.MyCommand.Path
    }
    else {
        $SourceDir = (Get-Location).Path
    }
}
# Normalize: trim trailing slashes that "%~dp0." or "%~dp0" may introduce.
$SourceDir = $SourceDir.TrimEnd('\').TrimEnd('/')

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
$Script:ExpectedFiles = @(
    "KwemaAlarmPlugin.dll",
    "Newtonsoft.Json.dll",
    "Certificates\KwemaAlarmPlugin.KwemaAlarmPlugin.cert"
)

$Script:RegistryPaths = @(
    "HKLM:\SOFTWARE\Genetec\Security Center\Plugins\KwemaAlarmPlugin",
    "HKLM:\SOFTWARE\WOW6432Node\Genetec\Security Center\Plugins\KwemaAlarmPlugin"
)

$Script:GenetecParentDir = "C:\Program Files (x86)\Genetec Security Center 5.13"
$Script:LogsDir          = "C:\ProgramData\Genetec Security Center\Logs\KwemaAlarmPlugin"
$Script:Timestamp        = Get-Date -Format "yyyyMMdd_HHmmss"
$Script:TranscriptPath   = Join-Path $env:TEMP "KwemaInstall_$($Script:Timestamp).log"

# ---------------------------------------------------------------------------
# UI helpers
# ---------------------------------------------------------------------------
function Write-Step {
    param([int]$Number, [string]$Title)
    Write-Host ""
    Write-Host ("=" * 70) -ForegroundColor Cyan
    Write-Host (" STEP {0} - {1}" -f $Number, $Title) -ForegroundColor Cyan
    Write-Host ("=" * 70) -ForegroundColor Cyan
}

function Write-Ok    { param([string]$Message) Write-Host "  [OK]  $Message" -ForegroundColor Green }
function Write-Warn  { param([string]$Message) Write-Host "  [!!]  $Message" -ForegroundColor Yellow }
function Write-Fail  { param([string]$Message) Write-Host "  [XX]  $Message" -ForegroundColor Red }
function Write-Info  { param([string]$Message) Write-Host "  [..]  $Message" -ForegroundColor Gray }

function Read-Confirmation {
    param([string]$Prompt)
    while ($true) {
        $answer = Read-Host "$Prompt [Y/N]"
        switch -Regex ($answer.Trim().ToUpper()) {
            '^Y(ES)?$' { return $true }
            '^N(O)?$'  { return $false }
            default    { Write-Warn "Please answer Y (yes) or N (no)." }
        }
    }
}

# ---------------------------------------------------------------------------
# Steps
# ---------------------------------------------------------------------------
function Start-Welcome {
    Clear-Host
    Write-Host ""
    Write-Host "  +================================================================+" -ForegroundColor Cyan
    Write-Host "  |          INSTALLER - Kwema Alarm Plugin                        |" -ForegroundColor Cyan
    Write-Host "  |          Genetec Security Center 5.13                          |" -ForegroundColor Cyan
    Write-Host "  +================================================================+" -ForegroundColor Cyan
    Write-Host ""
    Write-Host "  This wizard will guide you through the full installation process." -ForegroundColor White
    Write-Host "  The Genetec Server service will be stopped for approximately"      -ForegroundColor White
    Write-Host "  30-60 seconds during deployment."                                  -ForegroundColor White
    Write-Host ""
    Write-Info "Running from: $SourceDir"
    Write-Info "Session log:  $($Script:TranscriptPath)"
    Write-Host ""

    Start-Transcript -Path $Script:TranscriptPath -Append | Out-Null
}

function Test-Prerequisites {
    Write-Step 1 "System prerequisites check"

    # Administrator privileges (#Requires already enforces, but we want a clear message).
    $current = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($current)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        Write-Fail "This session does NOT have administrator privileges."
        throw "Run PowerShell as Administrator and re-execute the script."
    }
    Write-Ok "Elevated PowerShell session (Administrator)."

    # Genetec installation folder.
    if (-not (Test-Path $Script:GenetecParentDir)) {
        Write-Fail "Genetec folder not found at: $($Script:GenetecParentDir)"
        throw "Genetec Security Center 5.13 does not appear to be installed on this machine."
    }
    Write-Ok "Genetec Security Center 5.13 detected."

    # GenetecServer service.
    $svc = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
    if (-not $svc) {
        Write-Fail "Windows service '$ServiceName' was not found."
        throw "Verify the service name or pass -ServiceName with the correct value."
    }
    Write-Ok "Service '$ServiceName' found (current status: $($svc.Status))."
}

function Test-PluginPackage {
    Write-Step 2 "Package files validation"

    if ([string]::IsNullOrWhiteSpace($SourceDir)) {
        throw "SourceDir is empty. Run the script from its own folder, or pass -SourceDir."
    }
    if (-not (Test-Path $SourceDir -PathType Container)) {
        throw "SourceDir does not exist: $SourceDir"
    }
    Write-Ok "Source folder: $SourceDir"

    foreach ($f in $Script:ExpectedFiles) {
        $full = Join-Path $SourceDir $f
        if (-not (Test-Path $full -PathType Leaf)) {
            Write-Fail "Required file not found: $f"
            throw "Make sure you extracted the full ZIP and are running this script from the extracted folder."
        }
        Write-Ok "Found: $f"
    }

    # Detect version from the parent folder name (e.g., extracted from KwemaAlarmPlugin-v1.0.0.zip).
    $script:DetectedVersion = "(unknown)"
    if ((Split-Path $SourceDir -Leaf) -match 'v(\d+\.\d+\.\d+)') {
        $script:DetectedVersion = $Matches[1]
    }
    Write-Ok "Detected package version: $script:DetectedVersion"
}

function Confirm-Installation {
    Write-Step 3 "Confirmation"

    Write-Host ""
    Write-Host "  Operation summary:" -ForegroundColor White
    Write-Host "  ----------------------------------------" -ForegroundColor DarkGray
    Write-Host "    Version to install : $script:DetectedVersion"
    Write-Host "    Destination folder : $InstallRoot"
    Write-Host "    Affected service   : $ServiceName  (will be stopped and restarted)"
    Write-Host "    Automatic backup   : Yes (if a previous installation exists)"
    Write-Host "  ----------------------------------------" -ForegroundColor DarkGray
    Write-Host ""

    if ($Silent) { return }

    if (-not (Read-Confirmation "  Do you want to continue with the installation?")) {
        throw "Installation cancelled by the operator."
    }
}

function Stop-ClientApps {
    Write-Step 4 "Close Security Desk and Config Tool"

    $clientProcesses = @("SecurityDesk", "ConfigTool")
    while ($true) {
        $running = Get-Process -Name $clientProcesses -ErrorAction SilentlyContinue
        if (-not $running) {
            Write-Ok "Security Desk and Config Tool are closed."
            break
        }

        Write-Warn "Client applications are currently running:"
        foreach ($p in $running) {
            Write-Host "        - $($p.ProcessName) (PID $($p.Id))" -ForegroundColor Yellow
        }
        Write-Host ""
        Write-Host "  Close these applications manually, then press Enter." -ForegroundColor Yellow
        if ($Silent) {
            throw "Client applications are open. Close them before running in Silent mode."
        }
        Read-Host "  Press Enter once they are closed" | Out-Null
    }
}

function Stop-GenetecService {
    Write-Step 5 "Stop service '$ServiceName'"

    $svc = Get-Service -Name $ServiceName
    if ($svc.Status -eq 'Stopped') {
        Write-Ok "Service was already stopped."
        return
    }

    Write-Info "Stopping service (this may take up to 60 seconds)..."
    Stop-Service -Name $ServiceName -Force

    $deadline = (Get-Date).AddSeconds(60)
    while ((Get-Service -Name $ServiceName).Status -ne 'Stopped') {
        if ((Get-Date) -gt $deadline) {
            throw "Timeout while stopping service '$ServiceName'."
        }
        Start-Sleep -Seconds 2
    }
    Write-Ok "Service stopped."
}

function Backup-PreviousInstall {
    Write-Step 6 "Back up previous installation"

    if (-not (Test-Path $InstallRoot)) {
        Write-Info "No previous installation at $InstallRoot - this is a fresh install."
        New-Item -Path $InstallRoot -ItemType Directory -Force | Out-Null
        $script:BackupPath = $null
        return
    }

    $script:BackupPath = "${InstallRoot}.backup_$($Script:Timestamp)"
    Write-Info "Renaming previous folder..."
    Rename-Item -Path $InstallRoot -NewName (Split-Path $script:BackupPath -Leaf)
    Write-Ok "Backup created at: $script:BackupPath"

    New-Item -Path $InstallRoot -ItemType Directory -Force | Out-Null
}

function Copy-PluginFiles {
    Write-Step 7 "Copy files to destination"

    Write-Info "Copying from $SourceDir to $InstallRoot..."

    # Copy only the plugin files - never the script itself, INSTALL.md, etc.
    foreach ($f in $Script:ExpectedFiles) {
        $src = Join-Path $SourceDir   $f
        $dst = Join-Path $InstallRoot $f

        $dstDir = Split-Path $dst -Parent
        if (-not (Test-Path $dstDir)) {
            New-Item -Path $dstDir -ItemType Directory -Force | Out-Null
        }
        Copy-Item -Path $src -Destination $dst -Force

        $hashSrc = (Get-FileHash $src -Algorithm SHA256).Hash
        $hashDst = (Get-FileHash $dst -Algorithm SHA256).Hash
        if ($hashSrc -ne $hashDst) {
            throw "Hash mismatch after copy: $f"
        }
        Write-Ok "$f  (SHA256 verified)"
    }
}

function Register-PluginInRegistry {
    Write-Step 8 "Register plugin in Windows Registry"

    $dllPath = Join-Path $InstallRoot "KwemaAlarmPlugin.dll"
    if (-not (Test-Path $dllPath)) {
        throw "Main DLL not found at destination: $dllPath"
    }

    foreach ($p in $Script:RegistryPaths) {
        if (-not (Test-Path $p)) {
            New-Item -Path $p -Force | Out-Null
        }
        Set-ItemProperty -Path $p -Name "Enabled"                   -Value "True"   -Type String
        Set-ItemProperty -Path $p -Name "ServerModule"              -Value $dllPath -Type String
        Set-ItemProperty -Path $p -Name "ClientModule"              -Value $dllPath -Type String
        Set-ItemProperty -Path $p -Name "AddFoldersToAssemblyProbe" -Value "True"   -Type String
        Write-Ok "Keys written at: $p"
    }
}

function Start-GenetecService {
    Write-Step 9 "Start service '$ServiceName'"

    Write-Info "Starting service (Genetec may take up to 2 minutes)..."
    Start-Service -Name $ServiceName

    $deadline = (Get-Date).AddSeconds(120)
    while ((Get-Service -Name $ServiceName).Status -ne 'Running') {
        if ((Get-Date) -gt $deadline) {
            throw "Timeout while starting service '$ServiceName'."
        }
        Start-Sleep -Seconds 3
    }
    Write-Ok "Service is running."
}

function Invoke-Rollback {
    param([string]$FailedStep, [string]$ErrorMessage)

    Write-Step 99 "Rollback - restoring previous state"
    Write-Warn "Failed at: $FailedStep"
    Write-Warn "Detail: $ErrorMessage"

    if (-not $Silent) {
        Write-Host ""
        if (-not (Read-Confirmation "  Run automatic rollback now?")) {
            Write-Warn "Rollback skipped by operator."
            Write-Warn "Service '$ServiceName' is left STOPPED. Restore manually."
            return
        }
    }

    # Stop the service before touching files (it may have been left running
    # if failure occurred at Step 9 with the service partially up).
    try {
        $svc = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
        if ($svc -and $svc.Status -ne 'Stopped') {
            Write-Info "Stopping service before restoring..."
            Stop-Service -Name $ServiceName -Force
            $deadline = (Get-Date).AddSeconds(60)
            while ((Get-Service -Name $ServiceName).Status -ne 'Stopped') {
                if ((Get-Date) -gt $deadline) { break }
                Start-Sleep -Seconds 2
            }
        }
    } catch {
        Write-Warn "Could not stop the service cleanly: $_"
    }

    if ($script:BackupPath -and (Test-Path $script:BackupPath)) {
        # Restore previous version.
        if (Test-Path $InstallRoot) {
            Remove-Item -Path $InstallRoot -Recurse -Force
        }
        Rename-Item -Path $script:BackupPath -NewName (Split-Path $InstallRoot -Leaf)
        Write-Ok "Previous version restored at: $InstallRoot"

        # Re-point Registry to the restored DLL (values likely point to the same
        # path, but we rewrite them for consistency).
        $dllPath = Join-Path $InstallRoot "KwemaAlarmPlugin.dll"
        if (Test-Path $dllPath) {
            foreach ($p in $Script:RegistryPaths) {
                if (Test-Path $p) {
                    Set-ItemProperty -Path $p -Name "ServerModule" -Value $dllPath -Type String
                    Set-ItemProperty -Path $p -Name "ClientModule" -Value $dllPath -Type String
                }
            }
            Write-Ok "Registry keys point to the restored DLL."
        }

        # Restart service: with the previous version, the most useful action is
        # leaving Genetec operational so the customer is not impacted.
        try {
            Write-Info "Starting service with the previous version..."
            Start-Service -Name $ServiceName
            $deadline = (Get-Date).AddSeconds(120)
            while ((Get-Service -Name $ServiceName).Status -ne 'Running') {
                if ((Get-Date) -gt $deadline) { throw "Timeout" }
                Start-Sleep -Seconds 3
            }
            Write-Ok "Service running with the previous version."
        } catch {
            Write-Fail "Could not restart the service: $_"
            Write-Warn "Start service '$ServiceName' manually from services.msc."
        }
    }
    else {
        # Fresh install: nothing to roll back to. Clean up partial state and
        # leave the system in a known state, without restarting the service.
        Write-Warn "No previous version to restore (this was a fresh install)."

        if (Test-Path $InstallRoot) {
            Remove-Item -Path $InstallRoot -Recurse -Force
            Write-Ok "Partially copied folder removed: $InstallRoot"
        }

        foreach ($p in $Script:RegistryPaths) {
            if (Test-Path $p) {
                Remove-Item -Path $p -Recurse -Force
                Write-Ok "Registry key removed: $p"
            }
        }

        Write-Warn "Service '$ServiceName' is left STOPPED."
        Write-Warn "Start it manually when ready, or re-run this installer."
    }
}

function Test-Installation {
    Write-Step 10 "Final verification"

    $svc = Get-Service -Name $ServiceName
    if ($svc.Status -ne 'Running') {
        throw "Service is not Running after start."
    }
    Write-Ok "Service '$ServiceName' is running."

    foreach ($p in $Script:RegistryPaths) {
        $val = (Get-ItemProperty -Path $p -Name "ServerModule").ServerModule
        if (-not (Test-Path $val)) {
            throw "Registered path at $p does not exist on disk: $val"
        }
        Write-Ok "Registry $p points to an existing DLL."
    }

    Write-Host ""
    Write-Host "  +----------------------------------------------------------------+" -ForegroundColor Green
    Write-Host "  |                INSTALLATION COMPLETED                          |" -ForegroundColor Green
    Write-Host "  +----------------------------------------------------------------+" -ForegroundColor Green
    Write-Host ""
    Write-Host "  Next steps:" -ForegroundColor White
    Write-Host "    1. Open Genetec Config Tool."
    Write-Host "    2. Locate the 'KwemaAlarmPlugin' entity (or add it as a new Plugin entity)."
    Write-Host "    3. Configure: Business ID and API Key."
    Write-Host ""
    Write-Host "  Plugin logs:"
    Write-Host "    $Script:LogsDir\kwema_plugin_<YYYYMMDD>.log"
    Write-Host ""
    Write-Host "  This installation log:"
    Write-Host "    $Script:TranscriptPath"
    Write-Host ""
}

# ---------------------------------------------------------------------------
# Orchestration
# ---------------------------------------------------------------------------
$script:CurrentStep = "(start)"
$script:BackupPath  = $null

try {
    Start-Welcome
    Test-Prerequisites
    Test-PluginPackage
    Confirm-Installation
    Stop-ClientApps

    $script:CurrentStep = "Step 5: Stop service"
    Stop-GenetecService

    $script:CurrentStep = "Step 6: Backup"
    Backup-PreviousInstall

    $script:CurrentStep = "Step 7: Copy"
    Copy-PluginFiles

    $script:CurrentStep = "Step 8: Registry"
    Register-PluginInRegistry

    $script:CurrentStep = "Step 9: Start service"
    Start-GenetecService

    $script:CurrentStep = "Step 10: Verification"
    Test-Installation

    exit 0
}
catch {
    Write-Host ""
    Write-Fail "Error at $($script:CurrentStep): $_"
    Write-Host ""

    # Only attempt rollback if we already touched files or services.
    $rollbackSteps = @("Step 5: Stop service", "Step 6: Backup", "Step 7: Copy",
                       "Step 8: Registry", "Step 9: Start service")
    if ($rollbackSteps -contains $script:CurrentStep) {
        Invoke-Rollback -FailedStep $script:CurrentStep -ErrorMessage $_.Exception.Message
    }

    Write-Host ""
    Write-Info "Full session log: $Script:TranscriptPath"
    exit 1
}
finally {
    try { Stop-Transcript | Out-Null } catch { }
}
