#Requires -Version 5.1
<#
.SYNOPSIS
    Read-only verification of the KwemaAlarmPlugin installation.

.DESCRIPTION
    Confirms that the plugin is correctly deployed and operational on a
    Genetec Security Center 5.13 server. Checks the plugin DLL on disk,
    its dependencies, the Genetec service status, Windows Registry keys,
    and the presence of a recent plugin runtime log.

    The verifier is purely read-only and does NOT require administrator
    privileges. It can be run by any user who has read access to the
    Genetec installation folder and HKLM Registry hive (the default for
    standard Windows accounts).

.PARAMETER InstallRoot
    Folder where the plugin is deployed. Defaults to:
    C:\Program Files (x86)\Genetec Security Center 5.13\Plugins\KwemaAlarmPlugin

.PARAMETER ServiceName
    Genetec Windows service name. Defaults to: GenetecServer.

.PARAMETER LogsDir
    Plugin runtime logs folder. Defaults to:
    C:\ProgramData\Genetec Security Center\Logs\KwemaAlarmPlugin

.EXAMPLE
    .\Verify-Installation.ps1

.NOTES
    Exit code 0 if all checks pass, 1 if any check fails.
#>

[CmdletBinding()]
param(
    [string]$InstallRoot = "C:\Program Files (x86)\Genetec Security Center 5.13\Plugins\KwemaAlarmPlugin",
    [string]$ServiceName = "GenetecServer",
    [string]$LogsDir     = "C:\ProgramData\Genetec Security Center\Logs\KwemaAlarmPlugin"
)

$ErrorActionPreference = "Continue"

# ---------------------------------------------------------------------------
# UI helpers
# ---------------------------------------------------------------------------
function Write-Section {
    param([string]$Title)
    Write-Host ""
    Write-Host ("=" * 70) -ForegroundColor Cyan
    Write-Host (" {0}" -f $Title) -ForegroundColor Cyan
    Write-Host ("=" * 70) -ForegroundColor Cyan
}

function Write-Pass { param([string]$Message) Write-Host "  [PASS] $Message" -ForegroundColor Green }
function Write-Fail { param([string]$Message) Write-Host "  [FAIL] $Message" -ForegroundColor Red }
function Write-Note { param([string]$Message) Write-Host "  [INFO] $Message" -ForegroundColor Gray }

# ---------------------------------------------------------------------------
# Test harness
# ---------------------------------------------------------------------------
$Script:Pass = 0
$Script:Fail = 0

function Check {
    param(
        [string]$Name,
        [scriptblock]$Test
    )
    try {
        $result = & $Test
        if ($result) {
            Write-Pass $Name
            $Script:Pass++
        } else {
            Write-Fail $Name
            $Script:Fail++
        }
    } catch {
        Write-Fail "$Name - $($_.Exception.Message)"
        $Script:Fail++
    }
}

# ---------------------------------------------------------------------------
# Banner
# ---------------------------------------------------------------------------
Write-Host ""
Write-Host "  +================================================================+" -ForegroundColor Cyan
Write-Host "  |          VERIFIER - Kwema Alarm Plugin                         |" -ForegroundColor Cyan
Write-Host "  |          Installation Verification (read-only)                 |" -ForegroundColor Cyan
Write-Host "  +================================================================+" -ForegroundColor Cyan
Write-Host ""
Write-Note "Install root : $InstallRoot"
Write-Note "Service      : $ServiceName"
Write-Note "Logs folder  : $LogsDir"

# ---------------------------------------------------------------------------
# Section 1: Plugin DLL on disk
# ---------------------------------------------------------------------------
Write-Section "1. Plugin DLL on disk"

$dll = Join-Path $InstallRoot "KwemaAlarmPlugin.dll"
Check "DLL exists at $dll" { Test-Path $dll -PathType Leaf }

if (Test-Path $dll) {
    Get-Item $dll | Select-Object Name, LastWriteTime, Length |
        Format-Table -AutoSize | Out-Host

    [System.Diagnostics.FileVersionInfo]::GetVersionInfo($dll) |
        Select-Object FileVersion, ProductVersion, FileDescription |
        Format-List | Out-Host

    Write-Note "SHA256: $((Get-FileHash $dll -Algorithm SHA256).Hash)"
}

# ---------------------------------------------------------------------------
# Section 2: Dependencies
# ---------------------------------------------------------------------------
Write-Section "2. Dependencies"

Check "Newtonsoft.Json.dll present" {
    Test-Path (Join-Path $InstallRoot "Newtonsoft.Json.dll") -PathType Leaf
}
Check "Plugin certificate present" {
    Test-Path (Join-Path $InstallRoot "Certificates\KwemaAlarmPlugin.KwemaAlarmPlugin.cert") -PathType Leaf
}

# ---------------------------------------------------------------------------
# Section 3: Genetec service
# ---------------------------------------------------------------------------
Write-Section "3. Genetec service"

$svc = Get-Service -Name $ServiceName -ErrorAction SilentlyContinue
Check "Service '$ServiceName' exists"      { $null -ne $svc }
Check "Service is Running"                  { $svc -and $svc.Status -eq 'Running' }
Check "Service starts automatically (auto)" { $svc -and $svc.StartType -eq 'Automatic' }

if ($svc) {
    $svc | Select-Object Name, Status, StartType |
        Format-Table -AutoSize | Out-Host
}

# ---------------------------------------------------------------------------
# Section 4: Windows Registry
# ---------------------------------------------------------------------------
Write-Section "4. Windows Registry"

$regPaths = @(
    "HKLM:\SOFTWARE\Genetec\Security Center\Plugins\KwemaAlarmPlugin",
    "HKLM:\SOFTWARE\WOW6432Node\Genetec\Security Center\Plugins\KwemaAlarmPlugin"
)

foreach ($p in $regPaths) {
    Check "$p exists" { Test-Path $p }

    Check "$p Enabled = True" {
        (Get-ItemProperty $p -ErrorAction Stop).Enabled -eq 'True'
    }

    Check "$p ServerModule points to existing DLL" {
        $val = (Get-ItemProperty $p -ErrorAction Stop).ServerModule
        $val -and (Test-Path $val -PathType Leaf)
    }
}

# ---------------------------------------------------------------------------
# Section 5: Plugin runtime logs
# ---------------------------------------------------------------------------
Write-Section "5. Plugin runtime logs"

Check "Logs directory exists" { Test-Path $LogsDir -PathType Container }

if (Test-Path $LogsDir -PathType Container) {
    $logs = Get-ChildItem $LogsDir -Filter "kwema_plugin_*.log" -ErrorAction SilentlyContinue |
            Sort-Object LastWriteTime -Descending

    Check "At least one plugin log file exists" { $logs -and $logs.Count -gt 0 }

    if ($logs -and $logs.Count -gt 0) {
        $logs | Select-Object -First 3 Name, LastWriteTime, Length |
            Format-Table -AutoSize | Out-Host

        $today = Get-Date -Format "yyyyMMdd"
        Check "Log file from today ($today) exists" {
            ($logs | Where-Object { $_.Name -like "kwema_plugin_$today*" }).Count -gt 0
        }
    }
}

# ---------------------------------------------------------------------------
# Final verdict
# ---------------------------------------------------------------------------
$total = $Script:Pass + $Script:Fail

Write-Host ""
Write-Host ("=" * 70) -ForegroundColor Cyan

if ($Script:Fail -eq 0) {
    Write-Host ""
    Write-Host "   ALL CHECKS PASSED  ($Script:Pass / $total)" -ForegroundColor Green
    Write-Host "   The plugin is correctly installed and operational." -ForegroundColor Green
    Write-Host ""
    Write-Host "   Next step: open Genetec Config Tool and configure" -ForegroundColor Gray
    Write-Host "   Business ID + API Key on the plugin page."          -ForegroundColor Gray
    Write-Host ""
    exit 0
}
else {
    Write-Host ""
    Write-Host "   $Script:Fail CHECK(S) FAILED  ($Script:Pass passed of $total total)" -ForegroundColor Red
    Write-Host "   Review the [FAIL] lines above." -ForegroundColor Red
    Write-Host ""
    Write-Host "   Recommended actions:" -ForegroundColor Yellow
    Write-Host "     1. Re-run Install.bat to redeploy the plugin." -ForegroundColor Yellow
    Write-Host "     2. If failures persist, contact Kwema support and share:" -ForegroundColor Yellow
    Write-Host "        - This verifier output" -ForegroundColor Yellow
    Write-Host "        - The latest installer log: $env:TEMP\KwemaInstall_*.log" -ForegroundColor Yellow
    Write-Host ""
    exit 1
}
