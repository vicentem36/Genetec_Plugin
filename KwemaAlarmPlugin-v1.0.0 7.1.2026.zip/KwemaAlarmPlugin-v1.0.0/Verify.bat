@echo off
REM ===========================================================================
REM  KwemaAlarmPlugin - Double-click verifier launcher
REM
REM  Read-only verification of the installed plugin. Does NOT require
REM  administrator privileges - all checks query state without modifying it.
REM ===========================================================================

cd /d "%~dp0"

powershell -ExecutionPolicy Bypass -NoProfile -File "%~dp0Verify-Installation.ps1"

echo.
echo ============================================================
echo  Verification finished. Press any key to close this window.
echo ============================================================
pause >nul
